//npm i mysql2 --save
import mysql from 'mysql2'

const  connection = mysql.createConnection({
host:'localhost',
user:'root',
password:'',
database:'dog'
})

connection.connecect()

export default connection