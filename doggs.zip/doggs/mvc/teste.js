import Crud from './Crud'

//Crud.prototype.save

const crud = new Crud()

function gravar() {

let dog = {"dogsname":"Ringo","dogscolor":"Caramel","age":1.5}

crud.save(dog, function(dog){

})


}


