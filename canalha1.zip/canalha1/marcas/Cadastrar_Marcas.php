<h1>Cadastrar Marcas</h1>

<form action="?page=salvar_Marcas" method="post">
<input type="hidden" name="acao" value="cadastar">


<div class="card" style="Width: 30rem;">
    
<div>
    <div class="container mb-13">
        <label class="mt-3">Marcas</label>
        <input type="text" name="marca" class="form-control" placeholder="digite nome da marca"></input>
    </div>
    <div class="container mb-3">
        <button type="submit" class="btn btn-primary">Cadastrar</button>
    </div>
</div>
</form>